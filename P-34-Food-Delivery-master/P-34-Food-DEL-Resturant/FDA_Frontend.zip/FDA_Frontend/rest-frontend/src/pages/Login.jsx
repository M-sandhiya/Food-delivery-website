import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import '../styles/login.css';

const Login = () => {
  const { login } = useAuth();
  const navigate = useNavigate();

  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [loading, setLoading] = useState(false);

  const handleSubmit = (e) => {
    e.preventDefault();
    setLoading(true);

    const storedUser = JSON.parse(localStorage.getItem('registeredUser'));

    if (
      storedUser &&
      storedUser.email === email &&
      storedUser.password === password
    ) {
      const user = {
        token: 'MOCK_JWT_TOKEN',
        user: {
          id: 'rest123',
          name: storedUser.name,
          email: storedUser.email,
          restaurantId: 'res001',
          role: 'RESTAURANT', // ✅ Required for ProtectedRoute
        },
      };

      login(user); // ✅ Store in context
      navigate('/restaurant/dashboard');
    } else {
      alert('❌ Invalid credentials. Please try again or register.');
    }

    setLoading(false);
  };

  // ✅ Google login mock logic
  const handleGoogleLogin = () => {
    alert('✅ Signed in with Google (mock)');
    login({
      token: 'GOOGLE_MOCK_TOKEN',
      user: {
        id: 'rest_google',
        name: 'Google Restaurant',
        email: 'googleuser@gmail.com',
        restaurantId: 'res999',
        role: 'RESTAURANT',
      }
    });
    navigate('/restaurant/dashboard');
  };

  return (
    <div className="login-container">
      <form className="login-form" onSubmit={handleSubmit}>
        <h2>Restaurant Login</h2>

        <input
          type="email"
          placeholder="Email"
          value={email}
          onChange={(e) => setEmail(e.target.value)}
          required
        />

        <input
          type="password"
          placeholder="Password"
          value={password}
          onChange={(e) => setPassword(e.target.value)}
          required
        />

        <button type="submit" disabled={loading}>
          {loading ? 'Logging in...' : 'Login'}
        </button>

        <div className="google-login" onClick={handleGoogleLogin}>
          <img
            src="https://developers.google.com/identity/images/g-logo.png"
            alt="Google"
          />
          <span>Sign in with Google</span>
        </div>

        <p className="register-link">
          Don&apos;t have an account?{' '}
          <span onClick={() => navigate('/register')}>Register</span>
        </p>
      </form>
    </div>
  );
};

export default Login;
