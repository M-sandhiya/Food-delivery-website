// src/pages/restaurant/Profile.jsx
import React, { useState, useEffect } from 'react';
import '../../styles/profile.css';

const defaultProfile = {
  id: 'res001',
  name: 'Biryani House',
  email: 'biryanihouse@gmail.com',
  phone: '9876543210',
  address: 'MG Road, Bangalore',
  cuisineTypes: ['Biryani', 'North Indian'],
  coverImageUrl: 'https://cdn.example.com/cover.jpg',
  openStatus: true,
};

const Profile = () => {
  const [profile, setProfile] = useState(null);
  const [editing, setEditing] = useState(false);
  const [form, setForm] = useState({});
  const [imageFile, setImageFile] = useState(null);
  const [imagePreview, setImagePreview] = useState('');

  useEffect(() => {
    // Fetch or load mock profile
    const stored = localStorage.getItem('restaurantProfile');
    const loadedProfile = stored ? JSON.parse(stored) : defaultProfile;
    setProfile(loadedProfile);
    setForm(loadedProfile);
    setImagePreview(loadedProfile.coverImageUrl);
  }, []);

  const handleChange = (e) => {
    const { name, value, type, checked } = e.target;
    setForm((prev) => ({
      ...prev,
      [name]: type === 'checkbox' ? checked : value,
    }));
  };

  const handleCuisineChange = (e) => {
    const cuisines = e.target.value.split(',').map((c) => c.trim());
    setForm((prev) => ({ ...prev, cuisineTypes: cuisines }));
  };

  const handleImageChange = (e) => {
    const file = e.target.files[0];
    if (file) {
      setImageFile(file);
      const previewURL = URL.createObjectURL(file);
      setImagePreview(previewURL);
    }
  };

  const handleSubmit = (e) => {
    e.preventDefault();

    if (imageFile) {
      // Simulate image upload
      form.coverImageUrl = imagePreview;
    }

    setProfile(form);
    localStorage.setItem('restaurantProfile', JSON.stringify(form));
    setEditing(true);
    alert('✅ Profile updated (mock)');
  };

  const handleDelete = () => {
    if (window.confirm('Are you sure you want to delete your profile?')) {
      setProfile(null);
      localStorage.removeItem('restaurantProfile');
      alert('🗑️ Profile deleted (mock)');
    }
  };

  const handleRestore = () => {
    setProfile(defaultProfile);
    setForm(defaultProfile);
    setImagePreview(defaultProfile.coverImageUrl);
    localStorage.setItem('restaurantProfile', JSON.stringify(defaultProfile));
    alert('✅ Profile restored');
  };

  if (!profile) {
    return (
      <div className="profile-container">
        <h2>Profile Deleted</h2>
        <button onClick={handleRestore}>Restore Default Profile</button>
      </div>
    );
  }

  return (
    <div className="profile-container">
      <h2>🧾 Restaurant Profile</h2>

      <form className="profile-form" onSubmit={handleSubmit}>
        <label>
          Name:
          <input
            name="name"
            type="text"
            value={form.name}
            onChange={handleChange}
            disabled={!editing}
            required
          />
        </label>

        <label>
          Email:
          <input
            name="email"
            type="email"
            value={form.email}
            onChange={handleChange}
            disabled
          />
        </label>

        <label>
          Phone:
          <input
            name="phone"
            type="text"
            value={form.phone}
            onChange={handleChange}
            disabled={!editing}
          />
        </label>

        <label>
          Address:
          <input
            name="address"
            type="text"
            value={form.address}
            onChange={handleChange}
            disabled={!editing}
          />
        </label>

        <label>
          Cuisine Types:
          <input
            type="text"
            value={form.cuisineTypes.join(', ')}
            onChange={handleCuisineChange}
            disabled={!editing}
            placeholder="e.g., Biryani, South Indian"
          />
        </label>

        <label>
          Cover Image:
          {editing && (
            <input type="file" accept="image/*" onChange={handleImageChange} />
          )}
          {imagePreview && (
            <img
              src={imagePreview}
              alt="Cover"
              className="preview-img"
              style={{ maxWidth: '200px', marginTop: '10px' }}
            />
          )}
        </label>

        <label className="open-status">
          <input
            type="checkbox"
            name="openStatus"
            checked={form.openStatus}
            onChange={handleChange}
            disabled={!editing}
          />
          Open for Orders
        </label>

        <div className="profile-actions">
          {editing ? (
            <>
              <button type="submit">Save</button>
              <button
                type="button"
                className="cancel-btn"
                onClick={() => {
                  setForm(profile);
                  setEditing(false);
                }}
              >
                Cancel
              </button>
            </>
          ) : (
            <>
              <button type="button" onClick={() => setEditing(true)}>
                Edit
              </button>
              <button
                type="button"
                className="delete-btn"
                onClick={handleDelete}
              >
                Delete
              </button>
            </>
          )}
        </div>
      </form>
    </div>
  );
};

export default Profile;
