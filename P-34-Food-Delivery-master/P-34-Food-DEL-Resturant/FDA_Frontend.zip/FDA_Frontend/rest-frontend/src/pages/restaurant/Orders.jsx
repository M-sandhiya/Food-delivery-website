import React, { useState, useEffect } from 'react';
import '../../styles/orders.css';

// ✅ Mock Order Data
const mockOrders = [
  {
    orderId: 'ord567',
    customerName: 'Narayan Kumar',
    items: [
      { name: 'Chicken Biryani', quantity: 2 },
      { name: 'Paneer Tikka', quantity: 1 },
    ],
    totalAmount: 360,
    status: 'Pending',
    orderedAt: '2025-06-24T12:10:00',
  },
  {
    orderId: 'ord890',
    customerName: 'Sneha Reddy',
    items: [
      { name: 'Veg Burger', quantity: 1 },
    ],
    totalAmount: 150,
    status: 'Preparing',
    orderedAt: '2025-06-24T13:20:00',
  },
];

const Orders = () => {
  const [orders, setOrders] = useState([]);

  useEffect(() => {
    // Simulate fetch from API
    setOrders(mockOrders);
  }, []);

  const handleStatusChange = (orderId, newStatus) => {
    const updated = orders.map(order =>
      order.orderId === orderId ? { ...order, status: newStatus } : order
    );
    setOrders(updated);
  };

  return (
    <div className="orders-container">
      <h2>📦 Order Management</h2>

      {orders.length === 0 ? (
        <p>No orders yet.</p>
      ) : (
        <div className="order-list">
          {orders.map((order) => (
            <div className="order-card" key={order.orderId}>
              <div className="order-header">
                <strong>Order #{order.orderId}</strong>
                <span>Status: <b>{order.status}</b></span>
              </div>

              <p>👤 Customer: {order.customerName}</p>
              <p>🕒 Ordered At: {new Date(order.orderedAt).toLocaleString()}</p>

              <div className="order-items">
                <p>🍽️ Items:</p>
                <ul>
                  {order.items.map((item, i) => (
                    <li key={i}>{item.name} × {item.quantity}</li>
                  ))}
                </ul>
              </div>

              <p>💰 Total: ₹ {order.totalAmount}</p>

              <div className="order-actions">
                <select
                  value={order.status}
                  onChange={(e) =>
                    handleStatusChange(order.orderId, e.target.value)
                  }
                >
                  <option value="Pending">Pending</option>
                  <option value="Preparing">Preparing</option>
                  <option value="Out for Delivery">Out for Delivery</option>
                  <option value="Delivered">Delivered</option>
                  <option value="Rejected">Rejected</option>
                </select>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};

export default Orders;
