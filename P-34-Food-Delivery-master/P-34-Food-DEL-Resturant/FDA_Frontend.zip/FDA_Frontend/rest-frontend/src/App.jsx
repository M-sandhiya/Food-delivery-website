import React from 'react';
import RestaurantRoutes from './routes/RestaurantRoutes';

const App = () => (
  <RestaurantRoutes />
);

export default App;
