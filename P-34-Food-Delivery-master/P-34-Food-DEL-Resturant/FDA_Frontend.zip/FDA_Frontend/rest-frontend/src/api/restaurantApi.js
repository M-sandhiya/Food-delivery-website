import axios from 'axios';

const BASE_URL = 'http://localhost:8080/api/restaurant'; // Replace with backend base URL

// ✅ Get all menu items
export const getMenuItems = () => axios.get(`${BASE_URL}/menu`);

// ✅ Add a new menu item
export const addMenuItem = (itemData) => axios.post(`${BASE_URL}/menu`, itemData);

// ✅ Update menu item
export const updateMenuItem = (id, itemData) => axios.put(`${BASE_URL}/menu/${id}`, itemData);

// ✅ Delete menu item
export const deleteMenuItem = (id) => axios.delete(`${BASE_URL}/menu/${id}`);

// ✅ Get restaurant profile
export const getRestaurantProfile = () => axios.get(`${BASE_URL}/profile`);

// ✅ Update restaurant profile
export const updateRestaurantProfile = (data) => axios.put(`${BASE_URL}/profile`, data);

// ✅ Get all orders for this restaurant
export const getRestaurantOrders = () => axios.get(`${BASE_URL}/orders`);

// ✅ Update order status
export const updateOrderStatus = (orderId, status) =>
  axios.put(`${BASE_URL}/orders/${orderId}/status`, { status });

// ✅ Get restaurant dashboard statistics
export const getRestaurantDashboardStats = () => axios.get(`${BASE_URL}/dashboard`);
